﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TOP_GAMES
{
    public partial class FormCliente : Form
    {
        SqlConnection con = connect.ObterConexao();
         
        public FormCliente()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormCliente_Load(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            Cliente games = new Cliente();
            List<Cliente> games1 = games.listarcliente();
            dgvCliente.DataSource = games1;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            int aa = Convert.ToInt32(txtCEP.Text.Trim());
            int bb = Convert.ToInt32(txtIdade.Text.Trim());
            Cliente clie = new Cliente();
            clie.cadastrar(txtNome.Text, aa, bb);
            txtNome.Text = "";
            txtCEP.Text = "";
            txtIdade.Text = "";
            Cliente games = new Cliente();
            List<Cliente> games1 = games.listarcliente();
            dgvCliente.DataSource = games1;
            con.Close();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            int aa = Convert.ToInt32(txtId.Text.Trim());
            Cliente cliente = new Cliente();
            cliente.localizar(aa);
            txtNome.Text = cliente.nome;
            txtCEP.Text = cliente.cep.ToString();
            txtIdade.Text = cliente.idade.ToString();
            con.Close();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            int aa = Convert.ToInt32(txtId.Text.Trim());
            int bb = Convert.ToInt32(txtCEP.Text.Trim());
            int cc = Convert.ToInt32(txtIdade.Text.Trim());
            Cliente cliente = new Cliente();
            cliente.editar(aa, txtNome.Text, bb, cc);
            txtId.Text = "";
            txtNome.Text = "";
            txtCEP.Text = "";
            txtIdade.Text = "";
            Cliente games = new Cliente();
            List<Cliente> games1 = games.listarcliente();
            dgvCliente.DataSource = games1;
            con.Close();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            int aa = Convert.ToInt32(txtId.Text.Trim());
            Cliente cliente = new Cliente();
            cliente.excluir(aa);
            txtId.Text = "";
            txtNome.Text = "";
            txtCEP.Text = "";
            txtIdade.Text = "";
            Cliente games = new Cliente();
            List<Cliente> games1 = games.listarcliente();
            dgvCliente.DataSource = games;
            con.Close();
        }
    }
}
