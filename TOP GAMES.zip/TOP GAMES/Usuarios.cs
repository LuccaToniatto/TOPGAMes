﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace TOP_GAMES
{
    class Usuarios
    {
        public int Id { get; set; }
        public string login { get; set; }
        public string senha { get; set; }

        SqlConnection con = connect.ObterConexao();

        public List<Usuarios> listausuario()
        {
            List<Usuarios> usuarios = new List<Usuarios>();
            con.Close();
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Usuario";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Usuarios usuarios1 = new Usuarios();
                usuarios1.Id = (int)dr["Id"];
                usuarios1.login = dr["login"].ToString();
                usuarios1.senha = dr["senha"].ToString();
                usuarios.Add(usuarios1);
            }
            return usuarios;
        }

        public void Cadastrar(string login, string senha)
        {
            con.Close();
            con.Open();
            string sql = "INSERT INTO Usuario (login, senha) VALUES ('" + login + "','" + senha + "')";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void localizar(int Id)
        {
            con.Close();
            con.Open();
            string sql = "SELECT * FROM Usuario WHERE Id='" + Id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Usuarios usuarios = new Usuarios();
                Id = (int)dr["Id"];
                login = dr["login"].ToString();
                senha = dr["senha"].ToString();
            }
            con.Close();
        }

        public void editar(int Id, string login, string senha)
        {
            con.Close();
            con.Open();
            string sql = "UPDATE Usuario SET login='" + login + "', senha='" + senha + "' WHERE Id='" +Id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void excluir(int Id)
        {
            con.Close();
            con.Open();
            string sql = "DELETE FROM Usuario WHERE Id='" + Id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
