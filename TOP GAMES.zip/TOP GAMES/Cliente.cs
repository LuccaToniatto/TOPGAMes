﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace TOP_GAMES
{
    class Cliente
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public int cep { get; set; }
        public int idade { get; set; }

        SqlConnection con = connect.ObterConexao();

        public List<Cliente> listarcliente()
        {
            List<Cliente> artigos1 = new List<Cliente>();
            con.Close();
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Cliente";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Cliente artigos = new Cliente();
                artigos.Id = (int)dr["Id"];
                artigos.nome = dr["nome"].ToString();
                artigos.cep = (int)dr["cep"];
                artigos.idade = (int)dr["idade"];
                artigos1.Add(artigos);
            }
            return artigos1;
        }

        public void cadastrar(string nome, int cep, int idade)
        {
            con.Close();
            con.Open();
            string sql = "INSERT INTO Cliente (nome, cep, idade) VALUES ('" + nome + "','" + cep + "','"+idade+"')";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void localizar(int Id)
        {
            con.Close();
            con.Open();
            string sql = "SELECT * FROM Cliente WHERE Id='" + Id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Usuarios usuarios = new Usuarios();
                Id = (int)dr["Id"];
                nome = dr["nome"].ToString();
                cep = (int)dr["cep"];
                idade = (int)dr["idade"];
            }
            con.Close();
        }

        public void editar (int Id, string nome, int cep, int idade)
        {
            con.Close();
            con.Open();
            string sql = "UPDATE Cliente SET nome='" + nome + "', cep='" + cep + "',idade='" + idade + "' WHERE Id='" + Id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void excluir(int Id)
        {
            con.Close();
            con.Open();
            string sql = "DELETE FROM Cliente WHERE Id='" + Id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

    }
}
