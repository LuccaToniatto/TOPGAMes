﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TOP_GAMES
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void pbxSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pbxUsuario_Click(object sender, EventArgs e)
        {
            FrmUsuarios usu = new FrmUsuarios();
            usu.Show();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            connect.FecharConexao();
        }

        private void pbxArtigos_Click(object sender, EventArgs e)
        {
            FormArtigos art = new FormArtigos();
            art.Show();
        }

        private void pbxGames_Click(object sender, EventArgs e)
        {
            FormGames games = new FormGames();
            games.Show();
        }

        private void pbxClientes_Click(object sender, EventArgs e)
        {
            FormCliente cliente = new FormCliente();
            cliente.Show();
        }

        private void pbxVendaE_Click(object sender, EventArgs e)
        {
            FormVendas formVendas = new FormVendas();
            formVendas.Show();
        }

        private void pbxLocacaoes_Click(object sender, EventArgs e)
        {
            FormLocacao formLocacao = new FormLocacao();
            formLocacao.Show();
        }
    }
}
