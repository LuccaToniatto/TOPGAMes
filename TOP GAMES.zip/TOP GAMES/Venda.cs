﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace TOP_GAMES
{
    class Venda
    {
        public int Id { get; set; }
        public string cliente { get; set; }
        public int valor { get; set; }
        public string status { get; set; }

        SqlConnection con = connect.ObterConexao();

        public List<Venda> listavendas()
        {
            List<Venda> artigos1 = new List<Venda>();
            con.Close();
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            string status = "pendente";
            cmd.CommandText = "SELECT * FROM Vendas WHERE status='"+status+"'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Venda artigos = new Venda();
                artigos.Id = (int)dr["Id"];
                artigos.cliente = dr["cliente"].ToString();
                artigos.status = dr["status"].ToString();
                artigos1.Add(artigos);
            }
            return artigos1;
        }

        public void cadastrar(string cliente, string status)
        {
            con.Close();
            con.Open();
            string sql = "INSERT INTO Vendas (cliente,status) VALUES ('" + cliente + "','" + status + "')";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void localizar(int Id)
        {
            con.Close();
            con.Open();
            string sql = "SELECT * FROM Vendas WHERE Id='" + Id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Venda venda = new Venda();
                Id = (int)dr["Id"];
                cliente = dr["cliente"].ToString();
                status = dr["status"].ToString();
            }
            con.Close();
        }

        public void carregar(string produto)
        {
            con.Close();
            con.Open();
            string sql = "SELECT valor FROM Produto WHERE nome='" + produto + "' ";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Venda venda = new Venda();
                valor = (int)dr["valor"];
            }
            con.Close();
        }

        public void excluir(int Id, string cliente)
        {
            con.Close();
            con.Open();
            string sql = "DELETE FROM Vendas WHERE Id='"+Id+"'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            string sql2 = "DELETE FROM VendasPedido WHERE cliente='" + cliente + "'";
            SqlCommand cmd2 = new SqlCommand(sql2, con);
            cmd2.ExecuteNonQuery();
            con.Close();
        }

        public void confirmar(string cliente)
        {
            con.Close();
            con.Open();
            string confirmado = "confirmado";
            string sql = "UPDATE Vendas SET status ='" + confirmado + "' WHERE cliente='" + cliente + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            string sql2 = "DELETE FROM VendasPedido WHERE cliente='" + cliente + "'";
            SqlCommand cmd2 = new SqlCommand(sql2, con);
            cmd2.ExecuteNonQuery();
            con.Close();
        }
    }
}