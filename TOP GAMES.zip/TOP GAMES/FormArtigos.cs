﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TOP_GAMES
{
    public partial class FormArtigos : Form
    {
        public FormArtigos()
        {
            InitializeComponent();
        }

        private void FormArtigos_Load(object sender, EventArgs e)
        {
            Artigos artigos = new Artigos();
            List<Artigos> artigos1 = artigos.listaartigos();
            dgvArtigo.DataSource = artigos1;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            Artigos artigo = new Artigos();
            int vaa = Convert.ToInt32(txtValor.Text.Trim());
            int quaa = Convert.ToInt32(txtQuantidade.Text.Trim());
            connect.ObterConexao();
            string tipo = "2";
            artigo.cadastrar(txtNome.Text, vaa, quaa, tipo);
            txtNome.Text = "";
            txtValor.Text = "";
            txtQuantidade.Text = "";
            Artigos artigos = new Artigos();
            List<Artigos> artigos1 = artigos.listaartigos();
            dgvArtigo.DataSource = artigos1;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            Artigos artigos = new Artigos();
            int idd = Convert.ToInt32(txtId.Text.Trim());
            string tipo = "2";
            artigos.localizar(idd,tipo);
            txtNome.Text = artigos.nome;
            txtValor.Text = Convert.ToString(artigos.valor);
            txtQuantidade.Text = Convert.ToString(artigos.quantidade);
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            Artigos artigos = new Artigos();
            int dd = Convert.ToInt32(txtId.Text.Trim());
            int aa = Convert.ToInt32(txtValor.Text.Trim());
            int bb = Convert.ToInt32(txtQuantidade.Text.Trim());
            string tipo = "2";
            artigos.editar(dd, txtNome.Text, aa, bb,tipo);
            txtId.Text = "";
            txtNome.Text = "";
            txtValor.Text = "";
            txtQuantidade.Text = "";
            List<Artigos> artigos1 = artigos.listaartigos();
            dgvArtigo.DataSource = artigos1;

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            Artigos artigos = new Artigos();
            int dd = Convert.ToInt32(txtId.Text.Trim());
            string tipo = "2";
            txtId.Text = "";
            txtNome.Text = "";
            txtValor.Text = "";
            txtQuantidade.Text = "";
            artigos.excluir(dd,tipo);
            List<Artigos> artigos1 = artigos.listaartigos();
            dgvArtigo.DataSource = artigos1;
        }
    }
}
