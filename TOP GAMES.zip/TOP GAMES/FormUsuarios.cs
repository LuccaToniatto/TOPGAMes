﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TOP_GAMES
{
    public partial class FrmUsuarios : Form
    {

        SqlConnection con = connect.ObterConexao();

        public FrmUsuarios()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            con.Open();
            Usuarios usuarios = new Usuarios();
            usuarios.Cadastrar(txtLogin.Text, txtSenha.Text);
            txtLogin.Text = "";
            txtSenha.Text = "";
            List<Usuarios> usuarios1 = usuarios.listausuario();
            dgvUsuario.DataSource = usuarios1;
            con.Close();

        }

        private void FrmUsuarios_Load(object sender, EventArgs e)
        {
            con.Close();
            Usuarios usuarios = new Usuarios();
            List<Usuarios> usuarios1 = usuarios.listausuario();
            dgvUsuario.DataSource = usuarios1;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            con.Open();
            Usuarios usuarios = new Usuarios();
            int idd = Convert.ToInt32(txtId.Text.Trim());
            usuarios.localizar(idd);
            txtLogin.Text = usuarios.login;
            txtSenha.Text = usuarios.senha;
            con.Close();
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            con.Open();
            Usuarios usuarios = new Usuarios();
            int idd = Convert.ToInt32(txtId.Text.Trim());
            usuarios.editar(idd, txtLogin.Text, txtSenha.Text);
            txtId.Text = "";
            txtLogin.Text = "";
            txtSenha.Text = "";
            List<Usuarios> usuarios1 = usuarios.listausuario();
            dgvUsuario.DataSource = usuarios1;
            con.Close();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            con.Open();
            Usuarios usuarios = new Usuarios();
            int idd = Convert.ToInt32(txtId.Text.Trim());
            usuarios.excluir(idd);
            txtId.Text = "";
            txtLogin.Text = "";
            txtSenha.Text = "";
            List<Usuarios> usuarios1 = usuarios.listausuario();
            dgvUsuario.DataSource = usuarios1;
            con.Close();
        }
    }
}
