﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace TOP_GAMES
{
    class Games
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public int valor { get; set; }
        public int quantidade { get;set; }
        public string genero { get; set; }

        SqlConnection con = connect.ObterConexao();
        public List<Games> listargames()
        {
            List<Games> artigos1 = new List<Games>();
            con.Close();
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            string tipo = "1";
            cmd.CommandText = "SELECT * FROM Produto WHERE tipo = '"+tipo+"'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Games artigos = new Games();
                artigos.Id = (int)dr["Id"];
                artigos.nome = dr["nome"].ToString();
                artigos.valor = (int)dr["valor"];
                artigos.quantidade = (int)dr["quantidade"];
                artigos.genero = dr["genero"].ToString();
                artigos1.Add(artigos);
            }
            return artigos1;
        }

        public void cadastrar(string nome, int valor, int quantidade, string genero,string tipo)
        {
            con.Close();
            con.Open();
            string sql = "INSERT INTO Produto (nome,valor,quantidade,genero,tipo) VALUES ('" + nome + "','" + valor + "','" + quantidade + "','" + genero + "','"+tipo+"')";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void editar(int Id, string nome, int valor, int quantidade, string genero,string tipo)
        {
            con.Close();
            con.Open();
            string sql = "UPDATE Produto SET nome='" + nome + "', valor ='" + valor + "', quantidade='" + quantidade + "',genero ='" + genero + "' WHERE Id='" + Id + "' AND tipo='"+tipo+"'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void localizar(int Id, string tipo)
        {
            con.Close();
            con.Open();
            string sql = "SELECT * FROM Produto WHERE Id='" + Id + "' AND tipo='"+tipo+"'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Games usuarios = new Games();
                Id = (int)dr["Id"];
                nome = dr["nome"].ToString();
                valor = (int)dr["valor"];
                quantidade = (int)dr["quantidade"];
                genero = dr["genero"].ToString();
            }
            con.Close();
        }

        public void excluir(int Id,string tipo)
        {
            con.Close();
            con.Open();
            string sql = "DELETE FROM Produto WHERE Id='" + Id + "' AND tipo='"+tipo+"'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
