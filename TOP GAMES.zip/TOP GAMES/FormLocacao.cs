﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TOP_GAMES
{
    public partial class FormLocacao : Form
    {

        SqlConnection con = connect.ObterConexao();

        public FormLocacao()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormLocacao_Load(object sender, EventArgs e)
        {
            carregaCBXGame();
            Locacao locacao = new Locacao();
            List<Locacao> locacaoList = locacao.listalocacao();
            dgvlocacao.DataSource = locacaoList;
            CarregaCBXCliente();
        }
        public void carregaCBXGame()
        {
            con.Close();
            con.Open();
            string tipo = "1";
            string sql = "SELECT * FROM Produto WHERE tipo='" + tipo + "' ORDER BY nome";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Produto");
            cbxProduto.ValueMember = "Id";
            cbxProduto.DisplayMember = "nome".Trim();
            cbxProduto.DataSource = ds.Tables["Produto"];
            con.Close();
        }

        public void CarregaCBXCliente()
        {
            con.Close();
            con.Open();
            string sql = "SELECT * FROM Cliente ORDER BY nome";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "cliente");
            cbxCliente.ValueMember = "Id";
            cbxCliente.DisplayMember = "nome".Trim();
            cbxCliente.DataSource = ds.Tables["cliente"];
            con.Close();
        }

        private void btnCadastrarProduto_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            Locacao locacao = new Locacao();
            DateTime dta1 = dtpLocacao.Value;
            DateTime dta2 = dtpDevolucao.Value;
            int resultado = DateTime.Compare(dta1, dta2);
            if (resultado < 0)
            {
                int a = 0;
                locacao.cadastrar(cbxCliente.Text, cbxProduto.Text, dtpLocacao.Value, dtpDevolucao.Value,a);
                List<Locacao> locacaoList = locacao.listalocacao();
                dgvlocacao.DataSource = locacaoList;
                con.Close();
            }
            else
            {
                MessageBox.Show(Text = "nao pode");
                List<Locacao> locacaoList = locacao.listalocacao();
                dgvlocacao.DataSource = locacaoList;
                con.Close();
            }

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            DateTime dta1 = dtpLocacao.Value;
            DateTime dta2 = dtpDevolucao.Value;
            int TotalDia = (dta2.Subtract(dta1)).Days;
            int totalmesmo = TotalDia * 5;
            txtMulta.Text = Convert.ToString(totalmesmo);
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            int aa = Convert.ToInt32(txtId.Text);
            Locacao locacao = new Locacao();
            locacao.Localizar(aa);
            cbxCliente.Text = locacao.cliente;
            cbxProduto.Text = locacao.produto;
            dtpLocacao.Value = locacao.locacao;
            dtpDevolucao.Value = locacao.devolucao;
            txtMulta.Text = Convert.ToString(locacao.multa);
            con.Close();

        }

        private void btnEditarProduto_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            int aa = Convert.ToInt32(txtMulta.Text);
            int bb = Convert.ToInt32(txtId.Text);
            Locacao locacao = new Locacao();
            locacao.Atualizar(bb, cbxCliente.Text, cbxProduto.Text,dtpLocacao.Value,dtpDevolucao.Value,aa);
            List<Locacao> locacaoList = locacao.listalocacao();
            dgvlocacao.DataSource = locacaoList;
            con.Close();
        }

        private void btnExcluirProduto_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            int bb = Convert.ToInt32(txtId.Text);
            Locacao locacao = new Locacao();
            locacao.excluir(bb);
            List<Locacao> locacaoList = locacao.listalocacao();
            dgvlocacao.DataSource = locacaoList
            con.Close();
        }
    }
}
