﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace TOP_GAMES
{
    internal class Locacao
    {

        SqlConnection con = connect.ObterConexao();

        public int Id { get; set; }
        public string cliente { get; set; }
        public string produto { get; set; }
        public DateTime locacao { get; set; }
        public DateTime devolucao { get; set; }
        public int multa { get; set; }


        public List<Locacao> listalocacao()
        {
            List<Locacao> artigos1 = new List<Locacao>();
            con.Close();
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Locacao";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Locacao artigos = new Locacao();
                artigos.Id = (int)dr["Id"];
                artigos.cliente = dr["cliente"].ToString();
                artigos.produto = dr["produto"].ToString();
                artigos.locacao = Convert.ToDateTime(dr["locacao"]);
                artigos.devolucao = Convert.ToDateTime(dr["devolucao"]);
                artigos.multa = (int)dr["multa"];
                artigos1.Add(artigos);
            }
            return artigos1;
        }

        public void cadastrar(string cliente, string produto, DateTime locacao, DateTime devolucao,int multa)
        {
            con.Close();
            con.Open();
            string dta = locacao.ToString("yyyy/MM/dd");
            string dta2 = devolucao.ToString("yyyy/MM/dd");
            string sql = "INSERT INTO Locacao (cliente, produto, locacao, devolucao,multa) VALUES ('" + cliente + "','" + produto + "','" + dta + "','" + dta2 + "','"+multa+"')";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        
        public void Atualizar(int Id,string cliente, string produto, DateTime locacao, DateTime devolucao, int multa)
        {
            con.Close();
            con.Open();
            string dta = locacao.ToString("yyyy/MM/dd");
            string dta2 = devolucao.ToString("yyyy/MM/dd");
            string sql = "UPDATE Locacao SET cliente='" + cliente + "',produto='" + produto + "',locacao='"+dta+"',devolucao='"+dta2+"',multa='"+multa+"' WHERE Id='"+Id+"'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
        }

        public void Localizar(int Id)
        {
            con.Close();
            con.Open();
            string sql = "select * from Locacao where Id='" + Id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Locacao locacaoo = new Locacao();
               Id = (int)dr["Id"];
                cliente = dr["cliente"].ToString();
                produto = dr["produto"].ToString();
                locacao = Convert.ToDateTime(dr["locacao"]);
                devolucao = Convert.ToDateTime(dr["devolucao"]);
                multa = (int)dr["multa"];
            }
            con.Close();
        }

        public void excluir(int Id)
        {
            con.Close();
            con.Open();
            string sql = "DELETE FROM Locacao WHERE Id='" + Id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

    }
}
