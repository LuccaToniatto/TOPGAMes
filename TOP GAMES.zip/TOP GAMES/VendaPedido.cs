﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace TOP_GAMES
{
    class VendaPedido
    {

        SqlConnection con = connect.ObterConexao();

        public int Id { get; set; }
        public string cliente { get; set; }
        public string produto { get; set; }
        public int quantidade { get; set; }
        public int valor { get; set; }

        public void cadastrar(string cliente, string produto, int quantidade, int valor)
        {
            con.Close();
            con.Open();
            string sql = "INSERT INTO VendasPedido (cliente, produto, quantidade, valor) VALUES ('"+cliente+"','"+produto+"','"+quantidade+"','"+valor+"')";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();

        }

        public List<VendaPedido> listavendapedido2(string cliente)
        {
            List<VendaPedido> artigos1 = new List<VendaPedido>();
            con.Close();
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM VendasPedido WHERE cliente='"+cliente+"'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                VendaPedido artigos = new VendaPedido();
                artigos.Id = (int)dr["Id"];
                artigos.cliente = dr["cliente"].ToString();
                artigos.produto = dr["produto"].ToString();
                artigos.quantidade = (int)dr["quantidade"];
                artigos.valor = (int)dr["valor"];
                artigos1.Add(artigos);
            }
            return artigos1;
        }

        public void localizar(int Id)
        {
            con.Close();
            con.Open();
            string sql = "SELECT * FROM VendasPedido WHERE Id='" + Id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                VendaPedido vendaPedido = new VendaPedido();
                Id = (int)dr["Id"];
                cliente = dr["cliente"].ToString();
                produto = dr["produto"].ToString();
                quantidade = (int)dr["quantidade"];
                valor = (int)dr["valor"];
            }
        }

        public void editar(int Id, string produto, int valor, int quantidade)
        {
            con.Close();
            con.Open();
            string sql = "UPDATE VendasPedido SET produto='" + produto + "', valor='" + valor + "',quantidade='" + quantidade + "' WHERE Id='" + Id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

    }
}
