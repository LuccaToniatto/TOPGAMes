﻿namespace TOP_GAMES
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPrincipal));
            this.pbxGames = new System.Windows.Forms.PictureBox();
            this.pbxArtigos = new System.Windows.Forms.PictureBox();
            this.pbxClientes = new System.Windows.Forms.PictureBox();
            this.lblCliente = new System.Windows.Forms.Label();
            this.lblGames = new System.Windows.Forms.Label();
            this.lblArtigo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pbxVendaE = new System.Windows.Forms.PictureBox();
            this.pbxUsuario = new System.Windows.Forms.PictureBox();
            this.pbxLocacaoes = new System.Windows.Forms.PictureBox();
            this.pbxSair = new System.Windows.Forms.PictureBox();
            this.lblExit = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGames)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxArtigos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxClientes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVendaE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUsuario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLocacaoes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSair)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pbxGames
            // 
            this.pbxGames.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.pbxGames.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxGames.BackgroundImage")));
            this.pbxGames.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxGames.Location = new System.Drawing.Point(240, 12);
            this.pbxGames.Name = "pbxGames";
            this.pbxGames.Size = new System.Drawing.Size(208, 197);
            this.pbxGames.TabIndex = 0;
            this.pbxGames.TabStop = false;
            this.pbxGames.Click += new System.EventHandler(this.pbxGames_Click);
            // 
            // pbxArtigos
            // 
            this.pbxArtigos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.pbxArtigos.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxArtigos.BackgroundImage")));
            this.pbxArtigos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxArtigos.Location = new System.Drawing.Point(465, 12);
            this.pbxArtigos.Name = "pbxArtigos";
            this.pbxArtigos.Size = new System.Drawing.Size(208, 197);
            this.pbxArtigos.TabIndex = 1;
            this.pbxArtigos.TabStop = false;
            this.pbxArtigos.Click += new System.EventHandler(this.pbxArtigos_Click);
            // 
            // pbxClientes
            // 
            this.pbxClientes.BackColor = System.Drawing.Color.MediumAquamarine;
            this.pbxClientes.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxClientes.BackgroundImage")));
            this.pbxClientes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxClientes.Location = new System.Drawing.Point(12, 12);
            this.pbxClientes.Name = "pbxClientes";
            this.pbxClientes.Size = new System.Drawing.Size(208, 197);
            this.pbxClientes.TabIndex = 2;
            this.pbxClientes.TabStop = false;
            this.pbxClientes.Click += new System.EventHandler(this.pbxClientes_Click);
            // 
            // lblCliente
            // 
            this.lblCliente.AutoSize = true;
            this.lblCliente.BackColor = System.Drawing.Color.Transparent;
            this.lblCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCliente.Location = new System.Drawing.Point(12, 212);
            this.lblCliente.Name = "lblCliente";
            this.lblCliente.Size = new System.Drawing.Size(208, 25);
            this.lblCliente.TabIndex = 3;
            this.lblCliente.Text = "Gerenciar Clientes";
            // 
            // lblGames
            // 
            this.lblGames.AutoSize = true;
            this.lblGames.BackColor = System.Drawing.Color.Transparent;
            this.lblGames.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGames.Location = new System.Drawing.Point(243, 212);
            this.lblGames.Name = "lblGames";
            this.lblGames.Size = new System.Drawing.Size(195, 25);
            this.lblGames.TabIndex = 4;
            this.lblGames.Text = "Gerenciar Games";
            // 
            // lblArtigo
            // 
            this.lblArtigo.AutoSize = true;
            this.lblArtigo.BackColor = System.Drawing.Color.Transparent;
            this.lblArtigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArtigo.Location = new System.Drawing.Point(476, 212);
            this.lblArtigo.Name = "lblArtigo";
            this.lblArtigo.Size = new System.Drawing.Size(196, 25);
            this.lblArtigo.TabIndex = 5;
            this.lblArtigo.Text = "Gerenciar Artigos";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(460, 440);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 25);
            this.label1.TabIndex = 11;
            this.label1.Text = "Gerenciar Usuarios";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(231, 440);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(223, 25);
            this.label2.TabIndex = 10;
            this.label2.Text = "Gerenciar Locações";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(39, 440);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "Emitir Venda";
            // 
            // pbxVendaE
            // 
            this.pbxVendaE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pbxVendaE.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxVendaE.BackgroundImage")));
            this.pbxVendaE.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxVendaE.Location = new System.Drawing.Point(12, 240);
            this.pbxVendaE.Name = "pbxVendaE";
            this.pbxVendaE.Size = new System.Drawing.Size(208, 197);
            this.pbxVendaE.TabIndex = 8;
            this.pbxVendaE.TabStop = false;
            this.pbxVendaE.Click += new System.EventHandler(this.pbxVendaE_Click);
            // 
            // pbxUsuario
            // 
            this.pbxUsuario.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbxUsuario.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxUsuario.BackgroundImage")));
            this.pbxUsuario.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxUsuario.Location = new System.Drawing.Point(465, 240);
            this.pbxUsuario.Name = "pbxUsuario";
            this.pbxUsuario.Size = new System.Drawing.Size(208, 197);
            this.pbxUsuario.TabIndex = 7;
            this.pbxUsuario.TabStop = false;
            this.pbxUsuario.Click += new System.EventHandler(this.pbxUsuario_Click);
            // 
            // pbxLocacaoes
            // 
            this.pbxLocacaoes.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pbxLocacaoes.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxLocacaoes.BackgroundImage")));
            this.pbxLocacaoes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxLocacaoes.Location = new System.Drawing.Point(240, 240);
            this.pbxLocacaoes.Name = "pbxLocacaoes";
            this.pbxLocacaoes.Size = new System.Drawing.Size(208, 197);
            this.pbxLocacaoes.TabIndex = 6;
            this.pbxLocacaoes.TabStop = false;
            this.pbxLocacaoes.Click += new System.EventHandler(this.pbxLocacaoes_Click);
            // 
            // pbxSair
            // 
            this.pbxSair.BackColor = System.Drawing.Color.Salmon;
            this.pbxSair.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxSair.BackgroundImage")));
            this.pbxSair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxSair.Location = new System.Drawing.Point(240, 468);
            this.pbxSair.Name = "pbxSair";
            this.pbxSair.Size = new System.Drawing.Size(208, 197);
            this.pbxSair.TabIndex = 12;
            this.pbxSair.TabStop = false;
            this.pbxSair.Click += new System.EventHandler(this.pbxSair_Click);
            // 
            // lblExit
            // 
            this.lblExit.AutoSize = true;
            this.lblExit.BackColor = System.Drawing.Color.Salmon;
            this.lblExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExit.Location = new System.Drawing.Point(310, 671);
            this.lblExit.Name = "lblExit";
            this.lblExit.Size = new System.Drawing.Size(54, 25);
            this.lblExit.TabIndex = 13;
            this.lblExit.Text = "Sair";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 547);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 25);
            this.label5.TabIndex = 16;
            this.label5.Text = "TOP GAMES";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox5.Location = new System.Drawing.Point(12, 498);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(53, 50);
            this.pictureBox5.TabIndex = 21;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox6.Location = new System.Drawing.Point(167, 579);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(53, 50);
            this.pictureBox6.TabIndex = 20;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox7.Location = new System.Drawing.Point(29, 579);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(117, 108);
            this.pictureBox7.TabIndex = 22;
            this.pictureBox7.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(460, 547);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(146, 25);
            this.label4.TabIndex = 23;
            this.label4.Text = "TOP GAMES";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(596, 483);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(53, 50);
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(465, 579);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 50);
            this.pictureBox2.TabIndex = 25;
            this.pictureBox2.TabStop = false;
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(684, 705);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblExit);
            this.Controls.Add(this.pbxSair);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pbxVendaE);
            this.Controls.Add(this.pbxUsuario);
            this.Controls.Add(this.pbxLocacaoes);
            this.Controls.Add(this.lblArtigo);
            this.Controls.Add(this.lblGames);
            this.Controls.Add(this.lblCliente);
            this.Controls.Add(this.pbxClientes);
            this.Controls.Add(this.pbxArtigos);
            this.Controls.Add(this.pbxGames);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hub";
            this.Load += new System.EventHandler(this.FormPrincipal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxGames)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxArtigos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxClientes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVendaE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUsuario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLocacaoes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSair)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbxGames;
        private System.Windows.Forms.PictureBox pbxArtigos;
        private System.Windows.Forms.PictureBox pbxClientes;
        private System.Windows.Forms.Label lblCliente;
        private System.Windows.Forms.Label lblGames;
        private System.Windows.Forms.Label lblArtigo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pbxVendaE;
        private System.Windows.Forms.PictureBox pbxLocacaoes;
        private System.Windows.Forms.PictureBox pbxSair;
        private System.Windows.Forms.Label lblExit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pbxUsuario;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}