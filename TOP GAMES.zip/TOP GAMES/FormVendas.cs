﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TOP_GAMES
{
    public partial class FormVendas : Form
    {

        SqlConnection con = connect.ObterConexao();

        public FormVendas()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            Venda venda = new Venda();
            string status = "pendente";
            int valor = 0;
            venda.cadastrar(cbxCliente.Text,status);
            Venda games = new Venda();
            List<Venda> games1 = games.listavendas();
            dgvVenda.DataSource = games1;
            CarrecaCBXClienteProduto();
            con.Close();
        }

        private void FormVendas_Load(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            CarregaCBXCliente();
            CarrecaCBXClienteProduto();
            Venda games = new Venda();
            List<Venda> games1 = games.listavendas();
            dgvVenda.DataSource = games1;
            
        }

        public void CarrecaCBXArtigo()
        {
            con.Close();
            con.Open();
            string tipo = "2";
            string sql = "SELECT * FROM Produto WHERE tipo='" + tipo + "' ORDER BY nome";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Produto");
            cbxProduto.ValueMember = "Id";
            cbxProduto.DisplayMember = "nome".Trim();
            cbxProduto.DataSource = ds.Tables["Produto"];
            con.Close();
        }

        public void carregaCBXGame()
        {
            con.Close();
            con.Open();
            string tipo = "1";
            string sql = "SELECT * FROM Produto WHERE tipo='" + tipo + "' ORDER BY nome";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Produto");
            cbxProduto.ValueMember = "Id";
            cbxProduto.DisplayMember = "nome".Trim();
            cbxProduto.DataSource = ds.Tables["Produto"];
            con.Close();
        }

        private void btnCarregar1_Click(object sender, EventArgs e)
        {
            carregaCBXGame();
        }

        private void btnCarrega2_Click(object sender, EventArgs e)
        {
            CarrecaCBXArtigo();
        }

        public void CarregaCBXCliente()
        {
            con.Close();
            con.Open();
            string sql = "SELECT * FROM Cliente ORDER BY nome";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "cliente");
            cbxCliente.ValueMember = "Id";
            cbxCliente.DisplayMember = "nome".Trim();
            cbxCliente.DataSource = ds.Tables["cliente"];
            con.Close();
        }

        public void CarrecaCBXClienteProduto()
        {
            con.Close();
            con.Open();
            string status = "pendente";
            string sql = "SELECT * FROM Vendas WHERE status='"+status+"' ORDER BY cliente";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Vendas");
            cbxClienteProduto.ValueMember = "Id";
            cbxClienteProduto.DisplayMember = "cliente".Trim();
            cbxClienteProduto.DataSource = ds.Tables["Vendas"];
            con.Close();
        }

        private void btnCarregar_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            Venda venda = new Venda();
            venda.carregar(cbxProduto.Text.Trim());
            txtValorInicial.Text = (venda.valor.ToString());
            con.Close();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            Venda venda = new Venda();
            int aa = Convert.ToInt32(txtId.Text.Trim());
            venda.localizar(aa);
            cbxCliente.Text = venda.cliente;
            txtStatus.Text = venda.status;
            con.Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int aa = Convert.ToInt32(txtValorInicial.Text.Trim());
            int bb = Convert.ToInt32(txtQuantidade.Text.Trim());
            int cc = aa * bb;
            txtValorFinal.Text = (cc.ToString());
        }


        private void btnCadastrarProduto_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            int aa = Convert.ToInt32(txtValorFinal.Text.Trim());
            int bb = Convert.ToInt32(txtQuantidade.Text.Trim());
            VendaPedido vendaPedido = new VendaPedido();
            vendaPedido.cadastrar(cbxClienteProduto.Text, cbxProduto.Text, bb, aa);
            List<VendaPedido> vendaPedidos = vendaPedido.listavendapedido2(cbxClienteProduto.Text);
            dgvVendaPedido.DataSource = vendaPedidos;
            con.Close();
            con.Open();
        }

        private void btnLocalizar2_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            VendaPedido vendaPedido = new VendaPedido();
            List<VendaPedido> vendaPedidos = vendaPedido.listavendapedido2(cbxClienteProduto.Text);
            dgvVendaPedido.DataSource = vendaPedidos;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            Venda venda = new Venda();
            int aa = Convert.ToInt32(txtId.Text.Trim());
            venda.excluir(aa, cbxCliente.Text);
            Venda games = new Venda();
            List<Venda> games1 = games.listavendas();
            dgvVenda.DataSource = games1;
            VendaPedido vendaPedido = new VendaPedido();
            List<VendaPedido> vendaPedidos = vendaPedido.listavendapedido2(cbxClienteProduto.Text);
            dgvVendaPedido.DataSource = vendaPedidos;
            CarrecaCBXClienteProduto();
            con.Close();
        }

        private void btnEditarProduto_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            VendaPedido vendaPedido = new VendaPedido();
            int aa = Convert.ToInt32(txtIdProduto.Text.Trim());
            int bb = Convert.ToInt32(txtValorFinal.Text.Trim());
            int cc = Convert.ToInt32(txtQuantidade.Text.Trim());
            vendaPedido.editar(aa, cbxProduto.Text, bb, cc);
            List<VendaPedido> vendaPedidos = vendaPedido.listavendapedido2(cbxClienteProduto.Text);
            dgvVendaPedido.DataSource = vendaPedidos;
            con.Close();

        }

        private void txtLocalizarProduto_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            VendaPedido vendaPedido = new VendaPedido();
            int aa = Convert.ToInt32(txtIdProduto.Text.Trim());
            vendaPedido.localizar(aa);
            cbxProduto.Text = vendaPedido.produto;
            txtQuantidade.Text = Convert.ToString(vendaPedido.quantidade);
            txtValorFinal.Text = Convert.ToString(vendaPedido.valor);
        }


        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            Venda venda = new Venda();
            venda.confirmar(cbxCliente.Text);
            Venda games = new Venda();
            List<Venda> games1 = games.listavendas();
            dgvVenda.DataSource = games1;
            VendaPedido vendaPedido = new VendaPedido();
            List<VendaPedido> vendaPedidos = vendaPedido.listavendapedido2(cbxClienteProduto.Text);
            dgvVendaPedido.DataSource = vendaPedidos;
            con.Close();
        }
    }
}
