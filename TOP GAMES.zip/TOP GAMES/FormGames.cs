﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TOP_GAMES
{
    public partial class FormGames : Form
    {
        SqlConnection con = connect.ObterConexao();
        public FormGames()
        {
            InitializeComponent();
        }

        public void CarrecaCBXGene()
        {
            con.Close();
            con.Open();
            string sql = "SELECT * FROM Genero ORDER BY nome";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Genero");
            cbxGenero.ValueMember = "id";
            cbxGenero.DisplayMember = "nome".Trim();
            cbxGenero.DataSource = ds.Tables["Genero"];
            con.Close();
        }

        private void FormGames_Load(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            Games games = new Games();
            List<Games> games1 = games.listargames();
            dgvGames.DataSource = games1;
            CarrecaCBXGene();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            Games games = new Games();
            int aa = Convert.ToInt32(txtValor.Text.Trim());
            int bb = Convert.ToInt32(txtQuantidade.Text.Trim());
            int cc = Convert.ToInt32(txtIdade.Text.Trim());
            string tipo = "1";
            games.cadastrar(txtNome.Text, aa, bb, cbxGenero.Text,tipo);
            txtNome.Text = "";
            txtValor.Text = "";
            txtQuantidade.Text = "";
            txtIdade.Text = "";
            List<Games> games1 = games.listargames();
            dgvGames.DataSource = games1;
            con.Close();

        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            Games games = new Games();
            int aa = Convert.ToInt32(txtQuantidade.Text.Trim());
            int bb = Convert.ToInt32(txtValor.Text.Trim());
            int cc = Convert.ToInt32(txtId.Text.Trim());
            int dd = Convert.ToInt32(txtIdade.Text.Trim());
            string ee = Convert.ToString(txtNome.Text.Trim());
            string tipo = "1";
            txtId.Text = "";
            txtNome.Text = "";
            txtValor.Text = "";
            txtQuantidade.Text = "";
            txtIdade.Text = "";
            games.editar(cc,txtNome.Text, bb, aa,cbxGenero.Text,tipo);
            List<Games> games1 = games.listargames();
            dgvGames.DataSource = games1;
            con.Close();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            Games games = new Games();
            int aa = Convert.ToInt32(txtId.Text.Trim());
            string tipo = "1";
            games.localizar(aa,tipo);
            txtNome.Text = games.nome;
            txtValor.Text = Convert.ToString(games.valor);
            txtQuantidade.Text = Convert.ToString(games.quantidade);
            label5.Text = Convert.ToString(games.genero);
            cbxGenero.Text = Convert.ToString(games.genero);
            con.Close();

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            Games games = new Games();
            int aa = Convert.ToInt32(txtId.Text.Trim());
            string tipo = "1";
            games.excluir(aa,tipo);
            txtId.Text = "";
            txtNome.Text = "";
            txtValor.Text = "";
            txtQuantidade.Text = "";
            txtIdade.Text = "";
            List<Games> games1 = games.listargames();
            dgvGames.DataSource = games1;
            con.Close();
        }
    }
}
